var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => TalkTalkPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");

// src/tlkHighlighter.ts
var import_state = require("@codemirror/state");
var import_view = require("@codemirror/view");
var KEYWORDS = /* @__PURE__ */ new Set([
  "func",
  "let",
  "if",
  "else",
  "true",
  "false",
  "loop",
  "enum",
  "case",
  "match",
  "return",
  "struct",
  "extend",
  "break",
  "init",
  "protocol",
  "import"
]);
function matchOpeningFence(text) {
  const m = /^\s*(`{3,}|~{3,})[ \t]*tlk(?:[ \t]+.*)?$/.exec(text);
  if (!m) return null;
  return { char: m[1][0], len: m[1].length };
}
function isClosingFence(text, char, len) {
  const trimmed = text.trim();
  if (trimmed.length < len) return false;
  for (const c of trimmed) {
    if (c !== char) return false;
  }
  return true;
}
function tokenizeLine(text, lineFrom, blockComment, tokens) {
  const n = text.length;
  let i = 0;
  const push = (from, to, cls) => {
    if (to > from) tokens.push({ from: lineFrom + from, to: lineFrom + to, cls });
  };
  while (i < n) {
    if (blockComment.value) {
      const end = text.indexOf("*/", i);
      if (end === -1) {
        push(i, n, "cm-comment");
        return;
      }
      push(i, end + 2, "cm-comment");
      i = end + 2;
      blockComment.value = false;
      continue;
    }
    const ch = text[i];
    const next = i + 1 < n ? text[i + 1] : "";
    if (ch === "/" && next === "/") {
      push(i, n, "cm-comment");
      return;
    }
    if (ch === "/" && next === "*") {
      const end = text.indexOf("*/", i + 2);
      if (end === -1) {
        push(i, n, "cm-comment");
        blockComment.value = true;
        return;
      }
      push(i, end + 2, "cm-comment");
      i = end + 2;
      continue;
    }
    if (ch === "#" && next === '"') {
      let j = i + 2;
      while (j < n && text[j] !== '"') j++;
      j = Math.min(j + 1, n);
      push(i, j, "cm-variable");
      i = j;
      continue;
    }
    if (ch === '"' || ch === "'") {
      let j = i + 1;
      while (j < n) {
        if (text[j] === "\\") {
          j += 2;
          continue;
        }
        if (text[j] === ch) {
          j++;
          break;
        }
        j++;
      }
      push(i, j, "cm-string");
      i = j;
      continue;
    }
    if (ch >= "0" && ch <= "9") {
      const m = /^\d+(\.\d+)?/.exec(text.slice(i));
      const len = m ? m[0].length : 1;
      push(i, i + len, "cm-number");
      i += len;
      continue;
    }
    if (/[A-Za-z_]/.test(ch)) {
      const m = /^[A-Za-z_]\w*/.exec(text.slice(i));
      const word = m ? m[0] : ch;
      if (KEYWORDS.has(word)) push(i, i + word.length, "cm-keyword");
      i += word.length;
      continue;
    }
    i++;
  }
}
function buildDecorations(view) {
  const builder = new import_state.RangeSetBuilder();
  const doc = view.state.doc;
  const tokens = [];
  const blockComment = { value: false };
  let fence = null;
  for (let ln = 1; ln <= doc.lines; ln++) {
    const line = doc.line(ln);
    if (fence) {
      if (isClosingFence(line.text, fence.char, fence.len)) {
        fence = null;
        blockComment.value = false;
        continue;
      }
      tokenizeLine(line.text, line.from, blockComment, tokens);
    } else {
      fence = matchOpeningFence(line.text);
    }
  }
  const cache = /* @__PURE__ */ new Map();
  for (const t of tokens) {
    let deco = cache.get(t.cls);
    if (!deco) {
      deco = import_view.Decoration.mark({ class: t.cls });
      cache.set(t.cls, deco);
    }
    builder.add(t.from, t.to, deco);
  }
  return builder.finish();
}
var tlkHighlighter = import_view.ViewPlugin.fromClass(
  class {
    constructor(view) {
      this.decorations = buildDecorations(view);
    }
    update(update) {
      if (update.docChanged || update.viewportChanged) {
        this.decorations = buildDecorations(update.view);
      }
    }
  },
  { decorations: (v) => v.decorations }
);

// src/main.ts
var TalkTalkPlugin = class extends import_obsidian.Plugin {
  async onload() {
    const prism = await (0, import_obsidian.loadPrism)();
    prism.languages.tlk = {
      comment: [
        { pattern: /\/\*[\s\S]*?\*\//, greedy: true },
        { pattern: /\/\/.*/, greedy: true }
      ],
      "quoted-identifier": {
        pattern: /#"[^"\\\r\n]+"/,
        greedy: true,
        alias: "variable",
        inside: {
          punctuation: /^#"|"$/
        }
      },
      string: {
        pattern: /"(?:\\[\s\S]|[^"\\\r\n])*"/,
        greedy: true,
        inside: {
          escape: /\\./
        }
      },
      char: {
        pattern: /'(?:[^'\\\r\n]|\\(?:[ntr"'\\]|u\{[0-9A-Fa-f]{1,6}\}))'/,
        greedy: true,
        alias: "string"
      },
      keyword: /\b(?:func|let|if|else|true|false|loop|enum|case|match|return|struct|extend|break|init|protocol|import)\b/,
      number: /\b\d+(?:\.\d+)?\b/
    };
    this.registerEditorExtension(tlkHighlighter);
  }
};
